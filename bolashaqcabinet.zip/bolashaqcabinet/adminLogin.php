<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

$errorMsg = ''; // Инициализируем переменную для сообщения об ошибке

if (isset($_POST['login'])) {
    $staffId = $_POST['staffId'];
    $password = $_POST['password'];
    $password = md5($password);

    // Используем подготовленное выражение для защиты от SQL-инъекций
    $stmt = $con->prepare("SELECT * FROM tbladmin WHERE staffId=? AND password=?");
    $stmt->bind_param("ss", $staffId, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $_SESSION['staffId'] = $row['staffId'];
        $_SESSION['emailAddress'] = $row['emailAddress'];
        $_SESSION['firstName'] = $row['firstName'];
        $_SESSION['lastName'] = $row['lastName'];
        $_SESSION['adminTypeId'] = $row['adminTypeId'];

        if ($_SESSION['adminTypeId'] == 1) {
            echo "<script type=\"text/javascript\">window.location = (\"superAdmin/index.php\")</script>";
            exit(); // Добавим выход, чтобы избежать выполнения остального кода после перенаправления
        } else if ($_SESSION['adminTypeId'] == 2) {
            echo "<script type=\"text/javascript\">window.location = (\"admin/index.php\")</script>";
            exit();
        }
    } else {
        $errorMsg = "<div class='alert alert-danger' role='alert'>Неверное имя пользователя или пароль!</div>";
    }
}
?>

<!doctype html>
<!--[if gt IE 8]><!-->
<html class="no-js" lang=""> <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Оценка студента на PHP</title>
    <meta name="description" content="Ela Admin - HTML5 Шаблон администратора">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon">
    <!-- <link rel="shortcut icon" href="img/favicon2.jpeg" /> -->

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style2.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

    <!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
</head>
<body class="bg-light">

    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo">
                    <a href="index.html">
                    </a>
                </div>
                <div class="login-form">
                    <form method="post" action="">
                        <?php echo $errorMsg; ?>
                        <strong><h2 align="center">Вход в систему администратора</h2></strong><hr>
                        <div class="form-group">
                            <label>Почта</label>
                            <input type="text" name="staffId" required class="form-control" placeholder="Идентификатор персонала">
                        </div>
                        <div class="form-group">
                            <label>Пароль</label>
                            <input type="password" name="password" required class="form-control" placeholder="Пароль">
                        </div>
                        <div class="checkbox">
                           <label class="pull-left">
                                <a href="index.php">Вернуться</a>
                            </label>
                            <label class="pull-right">
                                <a href="#">Забыли пароль?</a>
                            </label>
                        </div>
                        <br>
                        <button type="submit" name="login" class="btn btn-success btn-flat m-b-30 m-t-30">Войти</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>

</body>
</html>
