<?php
$staffId = $_SESSION['staffId'];
$query = mysqli_query($con,"select * from tbladmin where staffId='$staffId'");
$row = mysqli_fetch_array($query);
$staffFullName = $row['firstName'].' '.$row['lastName'];
?>
<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">
        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="menu-title">ADMIN: &nbsp;&nbsp;&nbsp;<?php echo $staffFullName;?></li>
                <li class="<?php if($page=='dashboard'){ echo 'active'; }?>">
                    <a href="index.php"><i class="menu-icon fa fa-dashboard"></i>Главное </a>
                </li>
              
                <!-- <li class="menu-item-has-children dropdown <?php if($page=='session'){ echo 'active'; }?>">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false"> <i class="menu-icon fa fa-cogs"></i>Session</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="fa fa-plus"></i> <a href="createSession.php">Add New Session</a></li>
                    </ul>
                </li> -->
                   
                <li class="menu-title">Кабинет и Оборудование</li>
                <li class="menu-item-has-children dropdown <?php if($page=='faculty'){ echo 'active'; }?>">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false"> <i class="menu-icon fa fa-th"></i>Кабинет</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="fa fa-plus"></i> <a href="createFaculty.php">Добавить</a></li>
                        <li><i class="fa fa-eye"></i> <a href="viewFaculty.php">Список</a></li>
                    </ul>
                </li>
                
                <li class="menu-item-has-children dropdown <?php if($page=='department'){ echo 'active'; }?>">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false"> <i class="menu-icon fa fa-bars"></i>Оборудование</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="fa fa-plus"></i> <a href="createDepartment.php">Добавить</a></li>
                        <li><i class="fa fa-eye"></i> <a href="viewDepartment.php">Список</a></li>
                    </ul>
                </li>

                <li class="menu-title">Пользователи и обр.</li>
                <li class="menu-item-has-children dropdown <?php if($page=='student'){ echo 'active'; }?>">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false"> <i class="menu-icon fa fa-users"></i>Пользователи</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="fa fa-plus"></i> <a href="createStudent.php">Добавить</a></li>
                        <li><i class="fa fa-eye"></i> <a href="viewStudent.php">Список</a></li>
                    </ul>
                </li>

                <li class="menu-item-has-children dropdown <?php if($page=='courses'){ echo 'active'; }?>">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false"> <i class="menu-icon fa fa-book"></i>Оборудование</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="fa fa-plus"></i> <a href="createCourses.php">Добавить</a></li>
                        <li><i class="fa fa-eye"></i> <a href="viewCourses.php">Список</a></li>
                    </ul>
                </li>
                <!-- <li class="menu-title">Results and Grading</li>
                <li class="menu-item-has-children dropdown <?php if($page=='result'){ echo 'active'; }?>">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false"> <i class="menu-icon fa fa-file"></i>Result</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="fa fa-plus"></i> <a href="studentList.php">Compute GPA</a></li>
                        <li><i class="fa fa-plus"></i> <a href="studentList2.php">Compute CGPA</a></li>
                        <li><i class="fa fa-plus"></i> <a href="studentList3.php">View/Print Result</a></li>                     
                        <li><i class="fa fa-plus"></i> <a href="gradingCriteria.php">View Grading Criteria</a></li>
                    </ul>
                </li>
 -->
                <li class="menu-title">Аккаунт</li>
                <li class="menu-item-has-children dropdown <?php if($page=='profile'){ echo 'active'; }?>">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                        aria-expanded="false"> <i class="menu-icon fa fa-user-circle"></i>Профиль</a>
                    <ul class="sub-menu children dropdown-menu">
                        <!-- <li><i class="menu-icon fa fa-key"></i> <a href="changePassword.php">Change Password</a></li> -->
                        <li><i class="menu-icon fa fa-user"></i> <a href="updateProfile.php">Обновить профиль</a></li>
                    </ul>
                </li>
                <li>
                    <a href="logout.php"> <i class="menu-icon fa fa-power-off"></i>Выйти</a>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside>
